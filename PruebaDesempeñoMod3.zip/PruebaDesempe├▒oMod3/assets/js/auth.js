const API = "http://localhost:3000";

function saveUserSession(user) {
  sessionStorage.setItem("user", JSON.stringify(user));
}

function getUserSession() {
  return JSON.parse(sessionStorage.getItem("user"));
}

function logout() {
  sessionStorage.removeItem("user");
  location.hash = "login";
}

async function logLogin(user) {
  await fetch(`${API}/logins`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ userId: user.id, email: user.email, time: new Date().toISOString() })
  });
}

async function showLogins(container) {
  const user = getUserSession();
  if (!user || user.role !== "admin") {
    container.innerHTML = "<h3>Acceso denegado</h3>";
    return;
  }

  const res = await fetch(`${API}/logins`);
  const logs = await res.json();

  container.innerHTML = `
    <h3>Historial de Inicios de Sesión</h3>
    <ul class='list-group mt-3'></ul>
    <button class="btn btn-secondary mt-3" id="volverBtn">Volver</button>
  `;
  const ul = container.querySelector("ul");
  logs.forEach(log => {
    const li = document.createElement("li");
    li.className = "list-group-item";
    li.textContent = `${log.email} - ${new Date(log.time).toLocaleString()}`;
    ul.appendChild(li);
  });

  document.getElementById("volverBtn").addEventListener("click", () => navigateTo("app"));
}
