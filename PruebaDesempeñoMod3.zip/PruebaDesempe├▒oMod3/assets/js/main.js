document.addEventListener("DOMContentLoaded", router);
