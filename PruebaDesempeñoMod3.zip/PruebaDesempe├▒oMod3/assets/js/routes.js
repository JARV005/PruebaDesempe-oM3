function navigateTo(view) {
  location.hash = view;
}

function router() {
  const route = location.hash.replace("#", "") || "login";
  const app = document.getElementById("app");
  if (route === "login") return showLogin(app);
  if (route === "register") return showRegister(app);
  if (route === "app") return showApp(app);
  if (route === "logins") return showLogins(app);
}

window.addEventListener("hashchange", router);
